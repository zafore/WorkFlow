﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace WorkFlow.Controllers
{
    public class AccountController : Controller
    {
        private readonly ActiveDirectoryService _adService;

        public AccountController(ActiveDirectoryService adService)
        {
            _adService = adService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }


        //public IActionResult Login(string username, string password)
        //{
        //    if (_adService.ValidateUser(username, password))
        //    {
        //        var user = _adService.FindUser(username);
        //        if (user != null)
        //        {
        //            // Implement your logic for successful login
        //            // For example, create a claims identity and sign in the user
        //            return RedirectToAction("Index", "Home");
        //        }
        //    }

        //    // If we got this far, something failed; redisplay form
        //    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
        //    return View();
        //}

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (_adService.ValidateUser(username, password))
            {
                var user = _adService.FindUser(username);
                if (user != null)
                {
                    var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.SamAccountName),
                new Claim(ClaimTypes.Email, user.EmailAddress),
                // Add more claims as needed
            };

                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);
                     HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                    return RedirectToAction("Index", "Home");
                }
            }

            ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            return View();
        }
    }
}
