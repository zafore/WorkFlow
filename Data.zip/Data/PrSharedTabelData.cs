﻿namespace WorkFlow.Data
{
    //public virtual DbSet<PrSharedTabelData> PrSharedTabelDatas { get; set; }

    //public partial class PrSharedTabelData 
    //{
    //    public int DropIdTable { get; set; }
    //    public string Drop_Name { get; set; }
    //    public string Drop_Id { get; set; }
    //    public int Shared_Table_Id { get; set; }
    //}
    //modelBuilder.Entity<PrSharedTabelData>().HasKey(x => x.DropIdTable);
    //    modelBuilder.Entity<PrSharedTabelData>(entity =>
    //        {
    //            entity.Property(e => e.DropIdTable).HasColumnName("DropIdTable");
    //});
}
