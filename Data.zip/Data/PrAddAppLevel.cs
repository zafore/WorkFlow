﻿namespace WorkFlow.Data
{
	public class PrAddAppLevel
	{
		public int Application_Level_Id { get; set; }
		public string ApplicationId { get; set; }
		public string NodeID { get; set; }
		public string Application_Level_Name { get; set; }
		public string Column_Name_Value { get; set; }
		public string Tools_Id { get; set; }
		public string Is_Required { get; set; }
		public string Shared_Table_Id { get; set; }
		public string DisplaylinkId { get; set; }
	}
}
