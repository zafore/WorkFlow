﻿using System;
using System.Collections.Generic;

namespace WorkFlow.Models;

public partial class RelativeType
{
    public int RelativeTypeId { get; set; }

    public string RelativeTypeName { get; set; } = null!;
}
