﻿using System;
using System.Collections.Generic;

namespace WorkFlow.Models;

public partial class Employe
{
    public int EmployeId { get; set; }

    public string? Firstname { get; set; }

    public string? Middlename { get; set; }

    public string? Lastname { get; set; }

    public string? Address { get; set; }

    public string? Telephone { get; set; }

    public string? Emailaddress { get; set; }

    public DateTime? Birthdate { get; set; }

    public DateTime? Crdate { get; set; }

    public string? UserId { get; set; }

    public int? Bloodtypeid { get; set; }

    public string? Photo { get; set; }

    public string? Ministrycardno { get; set; }

    public int? MinistrycardtypeId { get; set; }

    public string? EmployeeNo { get; set; }

    public int? CompId { get; set; }

    public DateTime? MinistrycardnoExpire { get; set; }

    public int? NationalityId { get; set; }

    public string? MinistrycardnoFrom { get; set; }

    public string? RelativePersonOneName { get; set; }

    public string? RelationOne { get; set; }

    public string? RelativePersonTwoName { get; set; }

    public string? RelativePersonOneTel { get; set; }

    public string? RelationTwo { get; set; }

    public string? RelativePersonTwoTel { get; set; }

    public int? GenderId { get; set; }

    public DateTime? EmploymentDate { get; set; }

    public string? CrUserId { get; set; }

    public DateTime? CrDate1 { get; set; }

    public string? PassportNo { get; set; }

    public DateTime? PassportEndDate { get; set; }

    public string? NationalAddress { get; set; }

    public string? BorderNumber { get; set; }

    public string? ArabicName { get; set; }

    public int? SocialStatusId { get; set; }

    public string? IdentityProfession { get; set; }

    public string? IdentityLocation { get; set; }

    public DateTime? IdentityCardEndDate { get; set; }

    public int? ReligionId { get; set; }

    public string? Mobile { get; set; }

    public string? Gosino { get; set; }

    public int? AttendNo { get; set; }

    public bool? Hrpolicy { get; set; }

    public string? FnameAr { get; set; }

    public string? MnameAr { get; set; }

    public string? LnameAr { get; set; }

    public string? HealthInsurance { get; set; }

    public string? NationalAddress1 { get; set; }

    public int? GradeId { get; set; }

    public virtual ICollection<AttachmentDetail> AttachmentDetails { get; set; } = new List<AttachmentDetail>();

    public virtual ICollection<AttachmentMaster> AttachmentMasters { get; set; } = new List<AttachmentMaster>();

    public virtual ICollection<DepManager> DepManagers { get; set; } = new List<DepManager>();

    public virtual ICollection<Notification> Notifications { get; set; } = new List<Notification>();

    public virtual ICollection<Notifier> Notifiers { get; set; } = new List<Notifier>();

    public virtual ICollection<RequestLevel> RequestLevelAssignedToEmps { get; set; } = new List<RequestLevel>();

    public virtual ICollection<RequestLevelAssigned> RequestLevelAssigneds { get; set; } = new List<RequestLevelAssigned>();

    public virtual ICollection<RequestLevel> RequestLevelConversionToEmps { get; set; } = new List<RequestLevel>();

    public virtual ICollection<Request> Requests { get; set; } = new List<Request>();
}
