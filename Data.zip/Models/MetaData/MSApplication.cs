﻿using Microsoft.Build.Evaluation;
using System.ComponentModel.DataAnnotations;

namespace WorkFlow.Models
{
    
 
  


    public class ApplicationMetaData
    {


        [Display(Name = "Department Name")]
        public int DepartmentId { get; set; }
        [Display(Name = "اسم المعاملة ")]
        public string Application_Name_Eng { get; set; }
        [Display(Name = "اسم المعاملة ب ")]
        public string Application_Name_Ar { get; set; }
    }
}

    

